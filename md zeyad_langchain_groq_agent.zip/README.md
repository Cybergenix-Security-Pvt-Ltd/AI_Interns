# Modular LangChain Tool Agent with Groq LLM

## 🔧 Setup

1. Clone or download the code.
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Add your Groq API key to a `.env` file:
   ```
   GROQ_API_KEY=your_key_here
   ```

## 🚀 Run

```bash
python main.py
```

## ✅ Supported Prompts

- "What’s 15 * 3 + 2?"
- "What’s the weather in Delhi?"

## ➕ Adding New Tools

Drop a new file in `tools/` with a `@tool` function and it will auto-load!