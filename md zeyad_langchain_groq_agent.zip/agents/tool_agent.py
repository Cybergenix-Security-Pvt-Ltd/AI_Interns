import importlib
import os
from langchain.agents import initialize_agent, AgentType
from langchain.agents.agent_toolkits import Tool
from llm.groq_llm import get_llm

def load_tools():
    tools = []
    tools_folder = "tools"
    for filename in os.listdir(tools_folder):
        if filename.endswith(".py") and filename != "__init__.py":
            module_name = f"tools.{filename[:-3]}"
            module = importlib.import_module(module_name)
            for attr in dir(module):
                obj = getattr(module, attr)
                if callable(obj) and hasattr(obj, "args"):
                    tools.append(obj)
    return tools

def create_agent():
    tools = load_tools()
    llm = get_llm()
    agent = initialize_agent(
        tools,
        llm,
        agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
        verbose=True
    )
    return agent