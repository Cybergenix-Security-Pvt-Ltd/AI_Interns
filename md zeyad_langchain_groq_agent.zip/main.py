import sys
import os

sys.path.append(os.path.abspath("."))

from agents.tool_agent import create_agent

agent = create_agent()

print("🧠 Modular Tool Agent (type 'exit' to quit)\n")
while True:
    user_input = input(">> ")
    if user_input.lower() == "exit":
        print("👋 Exiting...")
        break
    response = agent.run(user_input)
    print("🤖", response)