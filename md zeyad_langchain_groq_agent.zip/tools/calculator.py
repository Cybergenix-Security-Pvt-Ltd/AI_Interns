from langchain.tools import tool

@tool
def calculator(expression: str) -> str:
    """Evaluate basic math expressions like '15 * 3 + 2'."""
    try:
        return str(eval(expression))
    except Exception as e:
        return f"Error: {str(e)}"