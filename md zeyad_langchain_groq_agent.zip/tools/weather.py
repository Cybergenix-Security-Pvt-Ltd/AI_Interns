from langchain.tools import tool

@tool
def weather(city: str) -> str:
    """Get fake weather for a given city (mocked for now)."""
    return f"The weather in {city} is sunny and 30°C."